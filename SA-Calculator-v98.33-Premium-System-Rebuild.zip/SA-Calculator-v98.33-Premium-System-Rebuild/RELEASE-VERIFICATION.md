# Release verification — v98.32

Release: `1.98.32-v98.32`  
Android versionCode: `1098032`

## Verified in this build environment
- `npm test`: 248 passed, 0 failed, 0 skipped.
- `node --check assets/js/app.js`: passed.
- `npm run build:web`: passed; 11 required assets verified.
- `www/assets/css/rebuild-v98.32.css` matches the source stylesheet.
- All four Android workflow YAML copies are byte-identical and parse successfully.
- Currency catalog contains 105 unique selectable codes and the flag registry covers them.
- Source archive integrity checked after packaging.

## Not certified
- The APK has not been built and installed on the user's physical Android phone in this run.
- Real-device screenshots, WebView IME behavior, live currency providers, FPS/jank, memory, battery, ANR and long-session stability still require physical-device testing.
- Source tests cannot prove universal zero-lag or zero-bug behavior.

Historical continuity: `1.98.2-v98.2` is referenced only as an earlier release baseline; current release identity remains `1.98.32-v98.32`.
