# QA results — v98.33

## Completed in the working source

- `node --check assets/js/app.js` — PASS.
- `node --check scripts/prepare-android-web.mjs` — PASS.
- `npm test` — 253 tests, 253 passed, 0 failed.
- `npm run build:web` — PASS; 12 required runtime assets verified and copied to `www/`.
- CSS brace balance — 298 opening / 298 closing braces.
- YAML parse — PASS for all synchronized workflow copies.
- Workflow copies — byte-identical.
- Source ZIP integrity — checked during packaging.

## Not verified in this environment

- Physical Android APK install/run on target phone.
- Real Android WebView screenshot/pixel comparison.
- Live currency provider availability on the user's network.
- Keyboard behavior across Android OEM keyboards and versions.
- FPS, frame jank, memory, battery, ANR and long-duration stress.

Automated source tests are not a substitute for physical-device QA. Do not interpret this report as a universal bug-free or lag-free certification.
