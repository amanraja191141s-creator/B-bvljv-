# SA Calculator v98.33 — Premium System Rebuild

A fresh source release for the SA Calculator Android/WebView application.

## What's new in v98.33

- Unified premium navy/blue UI layer across all 18 registered destinations.
- Rebuilt navigation drawer as a searchable categorized tool grid with separate Quick Access favorites.
- Unified screen toolbar, bottom navigation, safe-area handling, focus states and responsive sizing.
- Currency and Unit Converter no longer keep a keypad docked on screen; numeric entry uses the shared on-demand keypad.
- Number Base converter now opens its dedicated hexadecimal keypad only after a base row is selected and provides a Done action.
- Scientific functions use a compact grouped bottom sheet.
- Currency picker, settings, history, favorites, result states, forms and tool cards share a consistent visual system.
- Light/dark theme parity, landscape layout and reduced-motion support.

## Preserved application systems

The existing calculator expression engine, scientific math functions, currency-rate providers/cache, unit conversion catalogue, finance/date/fuel/body-metric calculation logic, persistence, localization, favorites, history and settings handlers are retained and regression-tested. They were not blindly replaced because they contain the app's calculation and data behavior.

## Development

```bash
npm install
npm test
npm run build:web
```

## Android APK

Use `SA-Calculator-v98.33-Android-Workflow.yml` in GitHub Actions, or use the repository workflow at `.github/workflows/main.yml`. The workflow selects the exact package version `1.98.33-v98.33`, runs regression tests, prepares the Capacitor web bundle, synchronizes Android, applies native branding/insets and builds a debug APK.

## Release verification boundaries

Automated source tests and web-bundle generation are verified in this release. A physical Android installation, live network currency refresh, device-specific WebView rendering, FPS/jank, memory, battery and ANR checks still require the target phone. No claim of universally zero-lag or bug-free behavior is made before those tests.
