# File-by-file release audit — v98.33

- `index.html`: version metadata updated; v98.33 stylesheet loaded after compatibility layers; hex keypad wrapped in an on-demand sheet; all original screen IDs and data hooks retained.
- `assets/css/rebuild-v98.33.css`: new authoritative visual layer for app shell, all 18 tool destinations, menus, toolbars, currency picker, scientific panel, keypads, forms, results, dialogs, themes and responsive modes.
- `assets/js/app.js`: version updated; Number Base keyboard now opens on base-row selection and closes via Done, Escape, Back/navigation.
- `scripts/prepare-android-web.mjs`: v98.33 stylesheet included in required assets and generated web bundle.
- `service-worker.js`: cache namespace bumped; v98.33 stylesheet precached; API responses remain excluded from cache.
- `package.json`, `manifest.webmanifest`: release version synchronized to `1.98.33-v98.33`.
- `.github/workflows/main.yml`, `android-apk.yml`, workflow aliases: exact v98.33 source selection, versionCode `1098033`, CSS checks and APK workflow synchronized.
- `tests/premium-system-v9833.test.js`: added checks for stylesheet order, tool keypad behavior, hex keypad lifecycle, screen coverage and release identity.
- `www/`: generated Capacitor web bundle rebuilt from the current source.

Compatibility note: `assets/css/app.css` and `assets/css/rebuild-v98.32.css` remain as a structural/compatibility base for existing component geometry and legacy selectors. The v98.33 stylesheet is loaded last and owns the new visible design. Calculation engines were intentionally preserved rather than rewritten.
