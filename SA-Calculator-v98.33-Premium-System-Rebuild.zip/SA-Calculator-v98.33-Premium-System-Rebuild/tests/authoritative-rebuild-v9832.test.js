const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

test('v98.32 removes competing currency picker and uses one searchable flag-aware picker', () => {
  const html = read('index.html'), js = read('assets/js/app.js'), css = read('assets/css/rebuild-v98.32.css');
  assert.doesNotMatch(html, /id="currency-picker-modal"/);
  assert.doesNotMatch(js, /function openCurrencyPicker\(/);
  assert.match(js, /const searchableCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(js, /currencyFlagForCode\(code\)/);
  assert.match(js, /localizedCurrencyName\(code\)/);
  assert.match(js, /sumaire-picker-option-flag/);
  assert.match(css, /\.sumaire-picker-option-flag/);
  assert.match(css, /select\.sumaire-select-native \{ display:none !important/);
});

test('v98.32 disables every pseudo toolbar and removes duplicate header actions', () => {
  const css = read('assets/css/rebuild-v98.32.css');
  assert.match(css, /#app-container #screen-viewport > \.screen::before,[\s\S]*?content:none !important/);
  assert.match(css, /#btn-header-settings,[\s\S]*?display:none !important/);
  assert.match(css, /body\.tool-screen-active #app-container > header\.app-header \{ display:none !important/);
});

test('v98.32 Body Metrics empty state has no blank status row and no success styling', () => {
  const html = read('index.html'), js = read('assets/js/app.js'), css = read('assets/css/rebuild-v98.32.css');
  assert.match(html, /id="body-metric-result" data-state="empty"/);
  assert.match(js, /emptyStatus\.textContent = ''; emptyStatus\.hidden = true/);
  assert.match(css, /#screen-bodymetrics #bmi-status\[hidden\]/);
  assert.match(css, /#body-metric-result\[data-state="empty"\]/);
});

test('v98.32 preserves on-demand keypad and calculator-only permanent keypad', () => {
  const html = read('index.html'), css = read('assets/css/rebuild-v98.32.css');
  assert.match(html, /id="popup-keypad-sheet"/);
  assert.match(html, /id="screen-calc"[\s\S]*?class="main-keypad"/);
  assert.match(css, /#popup-keypad-sheet \.popup-keypad-grid/);
});

test('v98.32 version, cache and Android workflow identities are synchronized', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  const html = read('index.html'), js = read('assets/js/app.js');
  const a = read('.github/workflows/main.yml'), b = read('android-apk.yml'), c = read('main-v98.32-authoritative-rebuild.yml');
  assert.equal(pkg.version, '1.98.33-v98.33');
  assert.equal(manifest.version, pkg.version);
  assert.match(html, /1\.98\.33-v98\.33/);
  assert.match(js, /APP_VERSION = '1\.98\.33-v98\.33'/);
  assert.match(read('service-worker.js'), /sa-calculator-v98-33-premium-system-rebuild/);
  assert.equal(a,b); assert.equal(b,c);
  assert.match(a,/versionCode='1098033'/);
  assert.match(a,/assets\/css\/rebuild-v98\.33\.css/);
});

test('v98.32 Fuel Efficiency empty and incomplete states are neutral; valid results alone are green', () => {
  const html = read('index.html'), js = read('assets/js/app.js'), css = read('assets/css/rebuild-v98.32.css');
  assert.match(html, /id="fuel-efficiency-result" data-state="empty"/);
  assert.match(js, /resultCard\.dataset\.state = hasAny \? 'incomplete' : 'empty'/);
  assert.match(js, /resultCard\.dataset\.state = 'success'/);
  assert.match(css, /#screen-fuelefficiency #fuel-efficiency-result\[data-state="empty"\]/);
  assert.match(css, /#screen-fuelefficiency #fuel-efficiency-result\[data-state="success"\]/);
});
