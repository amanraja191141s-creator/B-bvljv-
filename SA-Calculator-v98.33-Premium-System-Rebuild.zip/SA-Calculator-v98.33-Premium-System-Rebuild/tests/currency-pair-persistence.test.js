'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const app = fs.readFileSync(path.join(__dirname, '..', 'assets/js/app.js'), 'utf8');
function extractFunction(name) {
  const start = app.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} must exist`);
  const open = app.indexOf('{', start); let depth = 0;
  for (let i = open; i < app.length; i++) {
    if (app[i] === '{') depth++;
    else if (app[i] === '}' && --depth === 0) return app.slice(start, i + 1);
  }
  throw new Error(`Unclosed ${name}`);
}
test('selected ISO currency pair survives reload and is independent of rate updates', () => {
  const store = new Map();
  const localStorage = { getItem: k => store.get(k) ?? null, setItem: (k,v) => store.set(k,String(v)) };
  const context = { localStorage, Date, JSON, String, Set, CURRENCY_PAIR_STORAGE_KEY: 'sa_currency_selected_pair_v1', CURRENCY_CATALOG: ['USD','INR','EUR','CNY'] };
  vm.runInNewContext(`${extractFunction('loadSavedCurrencyPair')}\n${extractFunction('saveSelectedCurrencyPair')}\nglobalThis.load=loadSavedCurrencyPair; globalThis.save=saveSelectedCurrencyPair;`, context);
  assert.deepEqual(JSON.parse(JSON.stringify(context.load())), { from: 'USD', to: 'EUR' });
  assert.equal(context.save('EUR','USD'), true);
  assert.deepEqual(JSON.parse(JSON.stringify(context.load())), { from: 'EUR', to: 'USD' });
  // Rate values changing must not touch the saved ISO identity.
  const rates = { EUR: 1.08, USD: 1, INR: 83 };
  rates.EUR = 1.10;
  assert.deepEqual(JSON.parse(JSON.stringify(context.load())), { from: 'EUR', to: 'USD' });
  assert.equal(context.save('BAD','USD'), false);
  assert.deepEqual(JSON.parse(JSON.stringify(context.load())), { from: 'EUR', to: 'USD' });
});
test('currency picker and manual pair changes persist through the shared change handler', () => {
  assert.match(app, /fromSel\.addEventListener\('change',\s*\(\)\s*=>\s*\{\s*saveSelectedCurrencyPair\(fromSel\.value,\s*toSel\.value\)/);
  assert.match(app, /toSel\.addEventListener\('change',\s*\(\)\s*=>\s*\{\s*saveSelectedCurrencyPair\(fromSel\.value,\s*toSel\.value\)/);
  assert.match(app, /fromSel\.value=to;\s*toSel\.value=from;\s*saveSelectedCurrencyPair\(fromSel\.value,\s*toSel\.value\)/);
  assert.match(app, /const savedPair = loadSavedCurrencyPair\(\);\s*populateCurrencyOptions\(savedPair\.from, savedPair\.to\)/);
});
