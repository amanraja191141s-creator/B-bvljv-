# Release verification — v98.33

- Package: `1.98.33-v98.33`
- Android versionCode expected by workflow: `1098033`
- Service worker cache: `sa-calculator-v98-33-premium-system-rebuild`
- All runtime versions and four workflow copies synchronized.
- New authoritative stylesheet: `assets/css/rebuild-v98.33.css`.
- Previous v98.32 stylesheet retained as a compatibility/structural base; v98.33 stylesheet is loaded after it and owns the new visible design layer.
- Existing calculation engines and storage/data behavior retained.
- 253 automated tests passed; Android APK build and physical device QA pending.
